package com.example.pulserainteligente.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.pulserainteligente.R;
import com.google.firebase.database.FirebaseDatabase;

public class FirstFragment extends Fragment {

    private EditText etDeviceId;
    private Button btnConfirm;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etDeviceId = view.findViewById(R.id.etDeviceId);
        btnConfirm = view.findViewById(R.id.btnConfirmId);

        btnConfirm.setOnClickListener(v -> {
            String enteredId = etDeviceId.getText().toString().trim().toUpperCase();

            if (enteredId.isEmpty()) {
                Toast.makeText(getContext(), "Por favor ingrese un ID válido", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validar si existe en Firebase antes de navegar
            FirebaseDatabase.getInstance().getReference().child(enteredId)
                    .get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && task.getResult().exists()) {
                            // Guardar ID en SharedPreferences
                            SharedPreferences prefs = requireActivity().getSharedPreferences("APP_PREFS", Context.MODE_PRIVATE);
                            prefs.edit().putString("DEVICE_ID", enteredId).apply();

                            // Navegar al SecondFragment
                            NavHostFragment.findNavController(FirstFragment.this)
                                    .navigate(R.id.action_FirstFragment_to_SecondFragment);
                        } else {
                            Toast.makeText(getContext(), "Pulsera no encontrada", Toast.LENGTH_LONG).show();
                        }
                    });
        });

    }
}
