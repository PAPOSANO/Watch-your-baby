package com.example.pulserainteligente.utils;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.pulserainteligente.R;

public class AlertUtils {
    private static final String CHANNEL_ID = "baby_monitor_alerts";
    private static int notificationId = 0;
    private static long lastAlertTime = 0;
    private static final long ALERT_COOLDOWN_MS = 60 * 1000; // 1 minuto

    private static Ringtone currentRingtone;

    public static void showAlert(Context context, String title, String message, boolean isCritical) {
        long currentTime = System.currentTimeMillis();

        // Solo mostrar alerta crítica si ha pasado el tiempo mínimo
        if (isCritical) {
            if (currentTime - lastAlertTime < ALERT_COOLDOWN_MS) {
                return; // Evitar repetición
            }
            lastAlertTime = currentTime;

            showNotification(context, title, message);
            playAlarmSound(context);
        }

        // Mostrar diálogo solo si no es crítico o si sí toca mostrarlo ahora
        new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private static void playAlarmSound(Context context) {
        try {
            Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            currentRingtone = RingtoneManager.getRingtone(context, alarmSound);
            if (currentRingtone != null && !currentRingtone.isPlaying()) {
                currentRingtone.play();
            }

            // Detener después de 5 segundos para no ser molesto
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (currentRingtone != null && currentRingtone.isPlaying()) {
                    currentRingtone.stop();
                }
            }, 5000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void showNotification(Context context, String title, String message) {
        createNotificationChannel(context);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_alert)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        NotificationManagerCompat.from(context).notify(notificationId++, builder.build());
    }

    private static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Alertas Bebé";
            String description = "Alertas cuando los valores están fuera de rango";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
