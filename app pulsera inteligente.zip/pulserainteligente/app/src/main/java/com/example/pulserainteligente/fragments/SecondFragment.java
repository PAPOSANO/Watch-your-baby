package com.example.pulserainteligente.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.pulserainteligente.R;
import com.example.pulserainteligente.utils.AlertUtils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SecondFragment extends Fragment {

    private TextView tvTemperature, tvTempStatus, tvBPM, tvBPMStatus, tvSPO2, tvSPO2Status, tvLastUpdate;

    private static final float MIN_TEMP = 35f;
    private static final float MAX_TEMP = 38f;
    private static final int MIN_BPM = 90;
    private static final int MAX_BPM = 170;
    private static final int MIN_SPO2 = 60;
    private static final int MAX_SPO2 = 100;
    private Integer spo22;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        tvTemperature = view.findViewById(R.id.tvTemperature);
        tvTempStatus = view.findViewById(R.id.tvTempStatus);
        tvBPM = view.findViewById(R.id.tvBPM);
        tvBPMStatus = view.findViewById(R.id.tvBPMStatus);
        tvSPO2 = view.findViewById(R.id.tvSPO2);
        tvSPO2Status = view.findViewById(R.id.tvSPO2Status);
        tvLastUpdate = view.findViewById(R.id.tvLastUpdate);

        setupFirebaseListener();
    }

    private void setupFirebaseListener() {
        SharedPreferences prefs = requireActivity().getSharedPreferences("APP_PREFS", Context.MODE_PRIVATE);
        String deviceId = prefs.getString("DEVICE_ID", null);

        if (deviceId == null) {
            Toast.makeText(getContext(), "No se ha seleccionado ninguna pulsera", Toast.LENGTH_LONG).show();
            return;
        }

        FirebaseDatabase.getInstance().getReference().child(deviceId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists()) {
                            Toast.makeText(getContext(), "Pulsera no encontrada", Toast.LENGTH_LONG).show();
                            return;
                        }

                        Float temp = snapshot.child("temperatura").getValue(Float.class);
                        Integer bpm = snapshot.child("oximetro").child("bpm").getValue(Integer.class);
                        Integer spo2 = snapshot.child("oximetro").child("spo2").getValue(Integer.class);

                        Float Ftemp = snapshot.child("Ftemp").getValue(Float.class);
                        Integer Fbpm = snapshot.child("oximetro").child("Fbpm").getValue(Integer.class);
                        Integer Fbpm2 = snapshot.child("oximetro").child("Fbpm2").getValue(Integer.class);
                        Integer Fspo2 = snapshot.child("oximetro").child("Fspo2").getValue(Integer.class);

                        if (temp != 0 && bpm != 0 && spo2!=0) {
                            if (spo2+Fspo2>100){
                               spo22=100;
                            }else{spo22=spo2+Fspo2;}
                            updateUI(temp+Ftemp, (bpm+Fbpm2)/Fbpm, spo22);
                            checkForAlerts(temp, bpm, spo2);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("FirebaseError", "Error: " + error.getMessage());
                    }
                });
    }

    private void updateUI(float temp, int bpm, int spo2) {
        tvTemperature.setText(String.format(Locale.getDefault(), "%.1f °C", temp));
        tvTempStatus.setTextColor(getStatusColor(temp < MIN_TEMP ? "BAJA" : temp > MAX_TEMP ? "ALTA" : "NORMAL", tvTempStatus));

        tvBPM.setText(String.format(Locale.getDefault(), "%d BPM", bpm));
        tvBPMStatus.setTextColor(getStatusColor(bpm < MIN_BPM ? "BAJO" : bpm > MAX_BPM ? "ALTO" : "NORMAL", tvBPMStatus));

        tvSPO2.setText(String.format(Locale.getDefault(), "%d%%", spo2));
        tvSPO2Status.setTextColor(getStatusColor(spo2 < MIN_SPO2 ? "BAJA" : spo2 > MAX_SPO2 ? "ALTA" : "NORMAL", tvSPO2Status));

        tvLastUpdate.setText(String.format("Última actualización: %s", new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date())));
    }

    private int getStatusColor(String status, TextView view) {
        view.setText(status);
        if (status.equals("BAJA") || status.equals("BAJO")) return getResources().getColor(R.color.warning_color);
        if (status.equals("ALTA") || status.equals("ALTO")) return getResources().getColor(R.color.danger_color);
        return getResources().getColor(R.color.success_color);
    }

    private void checkForAlerts(float temp, int bpm, int spo2) {
        StringBuilder alerts = new StringBuilder();
        if (temp < MIN_TEMP || temp > MAX_TEMP) alerts.append("Temperatura ").append(temp < MIN_TEMP ? "baja" : "alta").append("\n");
        if (bpm < MIN_BPM || bpm > MAX_BPM) alerts.append("Ritmo cardíaco ").append(bpm < MIN_BPM ? "bajo" : "alto").append("\n");
        if (spo2 < MIN_SPO2 || spo2 > MAX_SPO2) alerts.append("Oxigenación ").append(spo2 < MIN_SPO2 ? "baja" : "alta");

        if (alerts.length() > 0) {
            AlertUtils.showAlert(requireContext(), "¡Alerta!", "Valores fuera de rango:\n" + alerts.toString(), true);
        }
    }
}
