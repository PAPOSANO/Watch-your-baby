package com.example.pulserainteligente.model;

public class BabyVitalSigns {
    private float temperatura;
    private int bpm;
    private int spo2;
    private long timestamp;

    public BabyVitalSigns() {
        // Constructor vacío requerido para Firebase
    }

    public BabyVitalSigns(float temperatura, int bpm, int spo2) {
        this.temperatura = temperatura;
        this.bpm = bpm;
        this.spo2 = spo2;
        this.timestamp = System.currentTimeMillis();
    }

    // Getters y Setters
    public float getTemperatura() {
        return temperatura;
    }

    public int getBpm() {
        return bpm;
    }

    public int getSpo2() {
        return spo2;
    }

    public long getTimestamp() {
        return timestamp;
    }
}