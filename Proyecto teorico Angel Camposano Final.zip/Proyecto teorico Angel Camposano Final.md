﻿![Texto

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.001.png)

![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.002.png)

**SISTEMAS DE EMBEBIDOS**
**\


**DOCUMENTO:** 

**PROPUESTA DE DISEÑO PRACTICO**

**PROYECTO:** 

**PULSERA INTELIGENTE PARA BEBES**

**TUTOR:** 

**MARIA ISABEL MERA COLLANTES**

**ESTUDIANTE:**  

**ANGEL CAMPOSANO COELLO**

**andacamp@espol.edu.ec**



1. # <a name="_toc57064"></a>Introducción
## La pulsera inteligente watch your baby es un dispositivo creado para el monitorea constante de los signos vitales de los bebes y así evitar cualquier tipo de preocupación causada por la muerte súbita. Este dispositivo consiste en la medición de tres parámetros importantes (Oxigeno en sangre, latidos por minuto y temperatura).
Su propósito es estar constantemente leyendo y mostrando a través de una app los signos vitales de los bebes para que los cuidadores puedan estar seguros de la estabilidad de ellos ya que si las lecturas encuentran alguna anomalía se alertara a los tutores directamente para que lo socorren.
## 1\.1. 	Objetivo general 
- ## <a name="_toc57067"></a>Monitorear la salud de un bebé mediante la construcción de una pulsera que lea constantemente sus signos vitales, para que los cuidadores puedan estar seguros de la estabilidad a través de una aplicación móvil.
## `	`1.2. 	Objetivos específicos 
- Diseñar un modelo de una pulsera lo suficientemente compacta y adecuada para el uso cómodo de un bebe.
- Otorgar una herramienta clave dentro de un núcleo familiar capaz de ayudar a controlar la salud de aquellos miembros familiares que requieren de mayor cuidado como lo son los bebes.
1. # Alcance y Limitaciones
**Alcance**

Este proyecto busca crear una pulsera inteligente para bebés que permita a los padres o cuidadores monitorear en tiempo real la frecuencia cardíaca, la temperatura y los niveles de oxígeno del bebé. La información se mostrará en una aplicación móvil, y si alguno de los valores está fuera de lo normal, se enviará una alerta inmediata con sonido, color de advertencia y un botón para apagar la alarma (que requiere mantenerse presionado para evitar errores). Además, la app guardará un historial de datos para hacer seguimiento, y el diseño de la pulsera será cómodo, ajustable e hipoalergénico. El dispositivo funcionará con una batería recargable de hasta 10 horas de duración.

**Limitaciones**

Aunque es una herramienta útil, no reemplaza una evaluación médica.

También hay algunas condiciones a tener en cuenta:

- Requiere Wi-Fi para enviar alertas a la app.
- Solo mide tres signos vitales, no otros parámetros como la presión arterial.
- Puede haber fallos de precisión si el bebé se mueve mucho o hay problemas de conexión.
- La batería debe cargarse diariamente para asegurar su funcionamiento.
- Sensores de baja resolución por mercado local y ausencia de maquinaria para utilizar microcomponentes.
1. # ![Imagen que contiene Patrón de fondo

El contenido generado por IA puede ser incorrecto.]Diagrama de contexto
1. ![Imagen que contiene Pizarra

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.004.png)![Diagrama, Esquemático

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.005.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.006.png)![Imagen que contiene Patrón de fondo

El contenido generado por IA puede ser incorrecto.]![Icono wifi | Canva]![Icono wifi | Canva]












   - # ![Logotipo

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.009.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.010.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.011.png)![Forma, Gráfico de líneas, Polígono

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.012.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.013.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.014.png)![PNG de celular](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.015.jpeg)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.016.png)![ref1]![Cuidado! Usar el celular en la cama podría causarte "ceguera transitoria",  dice estudio](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.018.jpeg)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.019.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.020.png)![Todos los datos de salud que pueden registrar los relojes inteligentes hoy  en día](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.021.jpeg)![ref1]![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.022.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.023.png)![Pierna del bebé acostado en la cama blanca | Foto Premium](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.024.jpeg)Diagrama de Bloques







   - ![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.025.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.026.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.027.png)

![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.028.png)![Diagrama

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.029.png)![Interfaz de usuario gráfica

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.030.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.031.png)





![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.032.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.033.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.034.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.035.png)



![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.036.png)

![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.037.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.038.png)





![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.039.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.040.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.041.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.042.png)![](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.043.png)
##
1. ## Estado del equipo existente

1. # Diseño de Interfases
# ![Interfaz de usuario gráfica, Aplicación, Chat o mensaje de texto

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.044.jpeg)![Interfaz de usuario gráfica, Aplicación, Teams

El contenido generado por IA puede ser incorrecto.](Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.045.jpeg)







1. # Alternativa de diseño
   Se pueden realizar varios cambios con respecto al diseño tanto de la pulsera como de la aplicación. En la pulsera se podría agregar una pantalla led que muestre los datos medidos directamente además del sistema ya diseñado. Para la parte de software se puede agregar un apartado de edades en la que según se selecciones los rangos de seguridad de signos vitales se adapte, así mismo, tener un apartado de registros de los datos previamente tomados para que un medico pueda realizar un análisis de crecimiento. Otro detalle es poner un botón de emergencia que llame directamente al número de emergencia.

1. # Plan de test y validación 
   El test se basa en utilizar la pulsera en varias personas para ir analizando los valores medidos y establecer factores de corrección que permitan sacar una aproximación más cercana de los valores reales, esto tomando en cuenta valores medidos con otros equipos con certificación. Además de esto, realizar pruebas con infantes para visualizar si se genera alguna molestia al momento de tenerlo puesto y que tenga un correcto funcionamiento. 
1. # Consideraciones Éticas 
   Aunque el dispositivo se desarrollo de una forma que se encuentre 100% encapsulado existe la posibilidad que se filtre químicos corrosivos y tóxicos de la batería hacia el bebe y esta le pueda crear lesiones graves, así mismo, habría que hacer un estudio de que tan dañino es tener las luces infrarrojas sobre la piel del infante debido a que estos son necesarios para la medición de los signos, pero son dañinos; al igual si esto genera algún tipo de deformación en el crecimiento de la parte (tobillo) donde se coloque. Establecer un botón de emergencia en la aplicación puede de ser de gran ayuda para una atención rápida y salvaguardar la vida de un bebe, pero existen falsas mediciones causadas por des posicionamiento del sensor que pueden llegar a alarmar a los padres y generar llamadas de emergencia innecesarias.


[Imagen que contiene Patrón de fondo

El contenido generado por IA puede ser incorrecto.]: Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.003.png
[Imagen que contiene Patrón de fondo

El contenido generado por IA puede ser incorrecto.]: Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.007.png
[Icono wifi | Canva]: Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.008.png
[ref1]: Aspose.Words.6e55aa3a-3c87-4232-b903-b29396029062.017.png
